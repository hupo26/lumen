<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It is a breeze. Simply tell Lumen the URIs it should respond to
| and give it the Closure to call when that URI is requested.
|
*/


$router->group([
    'prefix' => '/product'
], function ($router) {
    $router->post('UploadFile', 'ProductController@UploadFile'); //上传资源
    $router->post('ProductUpload', 'ProductController@ProductUpload'); //上传作品信息
    $router->post('UpLabel', 'ProductController@UpLabel'); //添加标签
    $router->post('getlist', 'ApiController@getlist'); //首页列表
    $router->post('getDetail', 'ApiController@getDetail'); //首页列表
    $router->post('detailZanState', 'ApiController@detailZanState'); //点赞高亮状态
    $router->post('zan', 'ApiController@zan'); //点赞
    $router->post('owninfo', 'ApiController@owninfo'); //我的信息
    $router->post('myProducts', 'ApiController@myProducts'); //我的作品
    $router->post('orderInfo', 'ApiController@myBuySaleProducts'); //我的购买/我已卖出
    $router->post('myZanProducts', 'ApiController@myZanProducts'); //我的点赞
    $router->post('myBag', 'ApiController@myBag'); //我的钱包
});
